from rest_framework import routers

from .spike_merge_viewset import (
    SpikeLogMergeViewSet,
)

V2_GENOME_ROUTER = routers.SimpleRouter()
V2_GENOME_ROUTER.register(
    r'spike-logs', SpikeLogMergeViewSet, basename='v2-spike-log'
)
