import json
import os
import uuid
from unittest.mock import mock_open, patch

from central_nervous_system.effectors.effector_casters.effector_handlers.effector_handler_codes import (
    HANDLER_INTERNAL_ERROR_CODE,
    HANDLER_SUCCESS_CODE,
    HANDLER_WRITE_ERROR_CODE,
)
from central_nervous_system.models import (
    Effector,
    NeuralPathway,
    Spike,
    SpikeStatus,
    SpikeTrain,
    SpikeTrainStatus,
)
from common.tests.common_test_case import CommonFixturesAPITestCase
from neuroplasticity.modifier_genome.unreal.code.are_self_unreal.version_metadata_handler import (
    update_version_metadata,
)

MODULE_PATH = (
    'neuroplasticity.modifier_genome.unreal.code.are_self_unreal.'
    'version_metadata_handler'
)


class VersionMetadataHandlerTest(CommonFixturesAPITestCase):
    fixtures = list(CommonFixturesAPITestCase.fixtures) + [
        'neuroplasticity/modifier_genome/unreal/modifier_data.json',
    ]

    def setUp(self):
        self.status_running = SpikeStatus.objects.get(id=SpikeStatus.RUNNING)
        self.spawn_running = SpikeTrainStatus.objects.get(
            id=SpikeTrainStatus.RUNNING
        )

        version_handler = uuid.UUID('1d037234-c8c2-4d51-bc65-41597c0becd2')
        self.effector = Effector.objects.create(
            name='Version Spell',
            executable_id=version_handler,
        )
        self.book = NeuralPathway.objects.create(name='Test Book')

        self.spike_train = SpikeTrain.objects.create(
            pathway=self.book, status_id=SpikeTrainStatus.RUNNING
        )

        self.spike = Spike.objects.create(
            spike_train=self.spike_train,
            effector=self.effector,
            status_id=SpikeStatus.RUNNING,
        )

    @patch('central_nervous_system.models.Effector.get_full_command')
    @patch(f'{MODULE_PATH}.log_system')  # Mute DB logging for speed
    def test_creates_new_file_if_missing(self, mock_log, mock_command):
        """Assert it creates a fresh JSON file if one doesn't exist."""
        target_path = 'C:/Fake/Content/AppVersion.json'
        mock_command.return_value = ['exe', target_path]

        with (
            patch('os.path.exists') as mock_exists,
            patch('os.makedirs') as mock_mkdirs,
            patch('builtins.open', new_callable=mock_open) as mock_file,
            patch(
                f'{MODULE_PATH}.getpass.getuser', return_value='TestBuilder'
            ),
        ):
            def exists_side_effect(path):
                if path == os.path.dirname(target_path):
                    return True
                if path == target_path:
                    return False
                return False

            mock_exists.side_effect = exists_side_effect

            code, log = update_version_metadata(self.spike.id)

            self.assertEqual(code, HANDLER_SUCCESS_CODE)
            self.assertIn('[SUCCESS]', log)

            handle = mock_file()
            written_content = ''.join(
                call.args[0] for call in handle.write.call_args_list
            )
            written_data = json.loads(written_content)

            self.assertIn('Build', written_data)
            self.assertEqual(written_data['Build']['Builder'], 'TestBuilder')
            self.assertEqual(written_data['Game']['Name'], 'HSH: Vacancy')

    @patch('central_nervous_system.models.Effector.get_full_command')
    @patch(f'{MODULE_PATH}.log_system')
    def test_updates_existing_file_preserving_data(
        self, mock_log, mock_command
    ):
        """Assert it updates 'Build' block but keeps existing 'Game' config."""
        target_path = 'C:/Fake/AppVersion.json'
        mock_command.return_value = ['exe', target_path]

        existing_content = json.dumps(
            {
                'Game': {
                    'Name': 'ExistingGame',
                    'Major': 9,
                    'Minor': 9,
                    'Patch': 9,
                },
                'OldBuild': 'LegacyData',
            }
        )

        with (
            patch('os.path.exists', return_value=True),
            patch(
                'builtins.open',
                new_callable=mock_open,
                read_data=existing_content,
            ) as mock_file,
        ):
            code, log = update_version_metadata(self.spike.id)

            self.assertEqual(code, HANDLER_SUCCESS_CODE)

            handle = mock_file()
            written_content = ''.join(
                call.args[0] for call in handle.write.call_args_list
            )
            data = json.loads(written_content)

            self.assertEqual(
                data['Game']['Major'], 9, 'Should preserve existing Game data'
            )
            self.assertIn('Build', data, 'Should inject Build block')
            self.assertIn('OldBuild', data, 'Should preserve unrelated keys')

    @patch('central_nervous_system.models.Effector.get_full_command')
    @patch(f'{MODULE_PATH}.log_system')
    def test_recovers_from_corrupt_json(self, mock_log, mock_command):
        """Assert it handles broken JSON by re-initializing the file."""
        target_path = 'C:/Fake/Corrupt.json'
        mock_command.return_value = ['exe', target_path]

        with (
            patch('os.path.exists', return_value=True),
            patch(
                'builtins.open',
                new_callable=mock_open,
                read_data='{ bad_json: ',
            ) as mock_file,
        ):
            code, log = update_version_metadata(self.spike.id)

            self.assertEqual(code, HANDLER_SUCCESS_CODE)
            self.assertIn('is corrupt', log)

            handle = mock_file()
            written_content = ''.join(
                call.args[0] for call in handle.write.call_args_list
            )
            data = json.loads(written_content)
            self.assertEqual(data['Game']['Name'], 'HSH: Vacancy')

    @patch('central_nervous_system.models.Effector.get_full_command')
    @patch(f'{MODULE_PATH}.log_system')
    def test_handles_directory_creation_failure(self, mock_log, mock_command):
        """Assert it returns specific error code if directory creation fails."""
        target_path = 'Z:/Protected/AppVersion.json'
        mock_command.return_value = ['exe', target_path]

        with (
            patch('os.path.exists', return_value=False),
            patch('os.makedirs', side_effect=OSError('Generic OS Failure')),
        ):
            code, log = update_version_metadata(self.spike.id)

            self.assertEqual(code, HANDLER_WRITE_ERROR_CODE)
            self.assertIn('Could not create directory', log)

    @patch('central_nervous_system.models.Effector.get_full_command')
    @patch(f'{MODULE_PATH}.log_system')
    def test_handles_file_write_failure(self, mock_log, mock_command):
        """Assert it returns internal error code if file write fails."""
        target_path = 'C:/Locked/AppVersion.json'
        mock_command.return_value = ['exe', target_path]

        with (
            patch('os.path.exists', return_value=False),
            patch('builtins.open', side_effect=IOError('Disk Full')),
        ):
            code, log = update_version_metadata(self.spike.id)

            self.assertEqual(code, HANDLER_INTERNAL_ERROR_CODE)
            self.assertIn('Version Stamp Failed', log)
