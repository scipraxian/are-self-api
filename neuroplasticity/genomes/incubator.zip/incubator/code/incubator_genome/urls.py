"""Hello-world example viewset for the incubator genome.

Exposes ``V2_GENOME_ROUTER`` so the V2 URL conf's bundle discovery
auto-registers the example route. No ORM dependency — the viewset
returns a static dict to demonstrate the bundle URL contract.

Use this file as a starting point for your own bundle's ``urls.py``.
"""

from rest_framework import routers, viewsets
from rest_framework.response import Response


class IncubatorHelloViewSet(viewsets.ViewSet):
    """Hello-world demo. Lives at ``/api/v2/incubator-hello/``.

    The list action returns the incubator's slug, version, and a short
    message — a smoke-test endpoint the frontend (or curl) can hit to
    confirm the bundle URL discovery is wired end-to-end.
    """

    def list(self, request):
        return Response(
            {
                'genome': 'incubator',
                'version': '0.0.0',
                'message': (
                    'Hello from the Incubator. This is your default '
                    'workspace - stamp rows here, then Save As to forge '
                    'them into a new genome.'
                ),
            }
        )


V2_GENOME_ROUTER = routers.SimpleRouter()
V2_GENOME_ROUTER.register(
    r'incubator-hello',
    IncubatorHelloViewSet,
    basename='incubator-hello',
)
