"""Incubator entry module — the default user workspace.

Importing this package is intentionally a no-op. The Incubator is a
real grafted genome (manifest, graft tree, bootstrapped from
``neuroplasticity/genomes/incubator.zip`` via ``graft_incubator()``)
but it ships zero side-effect registrations: no native handlers, no
parietal tools, no log parsers. Its only contribution is a
hello-world example viewset in ``urls.py`` so the bundle URL contract
has at least one live demonstration in the running system at all times.
"""
